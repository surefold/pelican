package dev.surefold.pelican

import java.nio.charset.StandardCharsets
import kotlin.reflect.KType

/**
 * Reads and writes a request or response body. Descriptions hold a [KType] and
 * never one of these, which is why swapping JSON libraries changes one line.
 */
interface BodyCodec<T> {
    fun encodeToString(value: T): String
    fun decodeFromString(text: String): T

    /**
     * The body as the bytes it arrived as, for a backend holding them already.
     * A JSON library reads UTF-8 directly; going through a String decodes the
     * whole body into UTF-16 first so the parser can scan it back.
     *
     * The default keeps every codec written against 1.0 working unchanged. See
     * spec 0046 for what overriding it is worth, measured.
     */
    fun decodeFrom(bytes: ByteArray): T = decodeFromString(String(bytes, StandardCharsets.UTF_8))

    /** Bytes this codec already holds, or null to encode as today. The server does not modify the array. */
    fun encoded(value: T): ByteArray? = null

    /**
     * [value] written into [sink], a backend's output buffer, with no String between (spec 0090). The default
     * writes [encoded] or [encodeToString]'s UTF-8 in one call; a JSON codec that streams overrides it.
     */
    fun encodeTo(value: T, sink: BodySink) {
        val bytes = encoded(value) ?: encodeToString(value).toByteArray(StandardCharsets.UTF_8)
        sink.write(bytes, 0, bytes.size)
    }
}

/** Where [BodyCodec.encodeTo] writes. Called any number of times, it copies the bytes before it returns. */
fun interface BodySink {
    fun write(bytes: ByteArray, offset: Int, length: Int)
}

/**
 * Thrown when a request body cannot be decoded. Backends wrap whatever the
 * codec threw, so mapping a bad body to a 400 names no JSON library.
 */
class BodyDecodeFailure(message: String, cause: Throwable? = null) : RuntimeException(message, cause)

/** Resolves a codec for a type. Implemented by `pelican-jackson`. */
interface CodecFactory {
    fun <T> codec(type: KType): BodyCodec<T>

    /**
     * How a value is written as [mediaType]. A JSON library supplies the one
     * encoding it knows; a service answering `text/csv` as well overrides this
     * and answers that media type with a writer of its own. See [MediaOutput].
     * A `+json` suffix (`application/problem+json`) is JSON, per RFC 6839.
     */
    fun <T> codec(type: KType, mediaType: String): BodyCodec<T> =
        if (isJson(mediaType)) codec(type)
        else error(
            "Nothing writes $type as $mediaType. A Codecs answers one encoding per type — the JSON one — " +
                "so a response declared as $mediaType needs a writer for it: override " +
                "codec(type, mediaType) on the Codecs this API was given and answer $mediaType there.",
        )

    /**
     * Reads JSON into core's own tree, for the places that need the shape of a
     * document rather than a value of a declared type — a form body's fields, a
     * JSON-RPC envelope, a tool result being published as `structuredContent`.
     *
     * The default is [parseJson], which is core's own small reader. A codec
     * module overrides it so those places are read by the library the service
     * already configured, and get that library's limits with it: `McpServer`
     * reads untrusted messages through here.
     *
     * Throws [BodyDecodeFailure] and nothing else, so a caller has one thing to
     * catch whichever library is underneath.
     */
    fun readTree(text: String): JsonValue =
        try {
            parseJson(text)
        } catch (e: IllegalArgumentException) {
            throw BodyDecodeFailure(e.message ?: "The text is not JSON", e)
        } catch (e: IllegalStateException) {
            throw BodyDecodeFailure(e.message ?: "The text is not JSON", e)
        }
}

/** The one encoding every [CodecFactory] has. The default [CodecFactory.codec] also answers `+json` types with it. */
const val JSON_MEDIA_TYPE: String = "application/json"

internal fun isJson(mediaType: String): Boolean {
    val essence = mediaType.substringBefore(';').trim().lowercase()
    return essence == JSON_MEDIA_TYPE || essence.endsWith("+json")
}

/**
 * Where named schemas accumulate while a document is being built. Schema
 * sources register component definitions here and return a `$ref` to them.
 */
interface SchemaComponents {
    fun register(name: String, schema: JsonObj)
    fun isRegistered(name: String): Boolean
    fun ref(name: String): JsonObj
}

/**
 * Describes a type as an OpenAPI schema. Separate from [CodecFactory] because
 * documentation has to be generatable without a server.
 */
interface SchemaSource {
    fun schema(type: KType, components: SchemaComponents): JsonObj
}

/**
 * The same schema with null allowed, spelled as OpenAPI 3.1 does: the dialect
 * is JSON Schema 2020-12, so a nullable string is `type: ["string", "null"]`.
 */
fun JsonObj.orNull(): JsonObj = when (val type = this["type"]) {
    is JsonStr -> this + jsonObj { put("type", jsonArr(listOf(type, JsonStr("null")))) }

    is JsonArr ->
        if (JsonStr("null") in type.items) this
        else this + jsonObj { put("type", JsonArr(type.items + JsonStr("null"))) }

    // No `type` to widen: a `$ref`, or a schema built out of `allOf`/`anyOf`.
    else -> jsonObj {
        put("anyOf", jsonArr(listOf(this@orNull, jsonObj { "type" to "null" })))
    }
}

/**
 * The same schema, agreeing with [type] about null at every depth.
 *
 * `List<Order?>` is the shape that needs it: erasure takes the element's
 * nullability, so a source deriving types from Java reflection cannot tell it
 * from `List<Order>`. Only the Kotlin type knows, so the two are walked
 * together — `items` and `additionalProperties` against the last type argument,
 * which is the element for `List`, `Array` and `Map` alike.
 *
 * A source already tracking nullability all the way down, as
 * kotlinx.serialization's descriptors do, should not call this over its work.
 */
fun JsonObj.withNullabilityOf(type: KType): JsonObj {
    val element = type.arguments.lastOrNull()?.type
    var schema = this
    if (element != null) {
        for (key in listOf("items", "additionalProperties")) {
            val child = schema[key] as? JsonObj ?: continue
            schema += jsonObj { put(key, child.withNullabilityOf(element)) }
        }
    }
    return if (type.isMarkedNullable) schema.orNull() else schema
}

/** A [CodecFactory] that also knows how to describe its types. */
interface Codecs : CodecFactory, SchemaSource

/** The default when none is configured: fails with an actionable message. */
object NoCodecs : Codecs {
    private fun fail(): Nothing = error(
        "No codecs configured. Pass `codecs = JacksonCodecs` to api(...), from pelican-jackson.",
    )

    override fun <T> codec(type: KType): BodyCodec<T> = fail()
    override fun schema(type: KType, components: SchemaComponents): JsonObj = fail()
}

/**
 * Which type each component name is being described from, and the refusal when
 * two want one name.
 *
 * All three schema sources name a component after the type's simple name, and
 * all three registered the second silently — so a document said `Item` once and
 * a consumer decoded the wrong one. Here rather than three times over, so the
 * three cannot differ about what a collision is or what to do about it.
 */
class SchemaNames {
    private val describedBy = mutableMapOf<String, String>()

    /** Records that [owner] is described as [name]. Refuses where something else already is. */
    fun claim(name: String, owner: String) {
        val already = describedBy.put(name, owner)
        require(already == null || already == owner) {
            "Two types are described as '$name': $already and $owner. A schema component is named " +
                "after the type, and a document holds one '$name', so the second would take the " +
                "first's schema and every reader of the document would believe it. Rename one, or " +
                "keep them out of the same document."
        }
    }
}

/** Default [SchemaComponents] implementation, used by the OpenAPI interpreter. */
class SchemaRegistry : SchemaComponents {
    private val components = LinkedHashMap<String, JsonObj>()

    override fun register(name: String, schema: JsonObj) { components[name] = schema }
    override fun isRegistered(name: String) = name in components
    override fun ref(name: String) = jsonObj { "\$ref" to "#/components/schemas/$name" }

    fun all(): JsonObj = JsonObj(components.toMap())
}
