package dev.surefold.pelican.pekko.docs

import dev.surefold.pelican.Api
import dev.surefold.pelican.CorsPolicy
import dev.surefold.pelican.corsPolicy
import dev.surefold.pelican.openapi.DocsUi
import dev.surefold.pelican.openapi.docs
import dev.surefold.pelican.openapi.oauth2RedirectHtml
import dev.surefold.pelican.openapi.oauth2RedirectPath
import dev.surefold.pelican.openapi.openApiJson
import dev.surefold.pelican.openapi.redocHtml
import dev.surefold.pelican.openapi.swaggerUiHtml
import dev.surefold.pelican.pekko.Handlers
import dev.surefold.pelican.pekko.PelicanServer
import dev.surefold.pelican.pekko.start
import dev.surefold.pelican.pekko.toRoute
import dev.surefold.pelican.pekko.withResponseHeaders
import dev.surefold.pelican.spi.CorsHeaders
import org.apache.pekko.actor.ClassicActorSystemProvider
import org.apache.pekko.actor.typed.ActorSystem
import org.apache.pekko.http.javadsl.model.ContentType
import org.apache.pekko.http.javadsl.model.ContentTypes
import org.apache.pekko.http.javadsl.model.HttpEntities
import org.apache.pekko.http.javadsl.model.HttpResponse
import org.apache.pekko.http.javadsl.model.StatusCodes
import org.apache.pekko.http.javadsl.model.headers.RawHeader
import org.apache.pekko.http.javadsl.server.Directives
import org.apache.pekko.http.javadsl.server.Route

/**
 * Serving documentation is the same decision on either backend, so the setting
 * is one type: [dev.surefold.pelican.openapi.Docs], next to the page it configures.
 * The alias keeps `dev.surefold.pelican.pekko.docs.Docs` a working import.
 */
typealias Docs = dev.surefold.pelican.openapi.Docs

/**
 * The document and the page, as routes — nothing else. Combine them yourself if
 * the service already has a route of its own to concat with.
 */
fun Api.docsRoutes(docs: Docs = docs()): List<Route> {
    val specPath = docs.openApiPath?.takeIf { it.isNotBlank() }
    val uiPath = docs.docsPath?.takeIf { it.isNotBlank() }
    if (specPath == null && uiPath == null && docs.referencePath == null) return emptyList()

    // Generated once and shared by the routes, rather than once per route.
    val document = spec().openApiJson(docs.version)

    // The API's own CORS setting covers the document as well: a spec a browser
    // tool cannot fetch is the same complaint as an endpoint it cannot call.
    // Reading it is a plain GET, so there is nothing to preflight.
    val cors = corsPolicy()

    return buildList {
        if (specPath != null) {
            add(staticRoute(specPath, ContentTypes.APPLICATION_JSON, document, cors))
        }
        if (uiPath != null) {
            // Null under Redoc without a second check: `docs { }` refuses
            // that renderer an `oauth` at all, so there is no flow to redirect.
            val redirectPath = docs.oauth?.let { oauth2RedirectPath(uiPath) }
            val page = when (docs.ui) {
                DocsUi.SwaggerUi -> swaggerUiHtml(title, specPath.orEmpty(), document, docs.oauth, redirectPath)
                DocsUi.Redoc -> redocHtml(title, specPath.orEmpty(), document, docs.redoc)
            }
            add(staticRoute(uiPath, ContentTypes.TEXT_HTML_UTF8, page, cors))
            // Next to the page, so the provider has one redirect URI to
            // register and it is on the docs' own origin.
            if (redirectPath != null) {
                add(staticRoute(redirectPath, ContentTypes.TEXT_HTML_UTF8, oauth2RedirectHtml(), cors))
            }
        }
        // Beside the page above, reading the same document: a reference for reading, a console for trying.
        docs.referencePage(title, specPath.orEmpty(), document)?.let { (path, page) ->
            add(staticRoute(path, ContentTypes.TEXT_HTML_UTF8, page, cors))
        }
    }.map { it.withResponseHeaders(this, isDocs = true) }
}

/** The endpoints and the documentation, as one route. */
fun Api.routeWithDocs(
    system: ClassicActorSystemProvider,
    docs: Docs = docs(),
    handlers: Handlers = Handlers.default,
): Route {
    val routes = listOf(toRoute(system, handlers)) + docsRoutes(docs)
    return routes.reduce { left, right -> Directives.concat(left, right) }
}

/** [start], with the document and the documentation page served alongside. */
fun Api.startWithDocs(
    port: Int = 8080,
    host: String = "127.0.0.1",
    systemName: String = "pelican",
    docs: Docs = docs(),
    handlers: Handlers = Handlers.default,
): PelicanServer = start(port, host, systemName) { system: ActorSystem<Void> ->
    routeWithDocs(system, docs, handlers)
}

/**
 * The same, on a system you already have. A service that brought its own
 * `ActorSystem` should not have to give up its documentation to keep it — and
 * [PelicanServer.stop] will unbind without terminating a system it borrowed.
 */
fun Api.startWithDocs(
    system: ActorSystem<Void>,
    port: Int = 8080,
    host: String = "127.0.0.1",
    docs: Docs = docs(),
    handlers: Handlers = Handlers.default,
): PelicanServer = start(system, port, host) { on: ActorSystem<Void> ->
    routeWithDocs(on, docs, handlers)
}

/** [routeWithDocs] as it was before spec 0058, kept so a caller compiled against RC2 still links. */
@Deprecated("Binary compatibility only: call routeWithDocs with handlers.", level = DeprecationLevel.HIDDEN)
fun Api.routeWithDocs(system: ClassicActorSystemProvider, docs: Docs = docs()): Route =
    routeWithDocs(system, docs, Handlers.default)

/** [startWithDocs] as it was before spec 0058. */
@Deprecated("Binary compatibility only: call startWithDocs with handlers.", level = DeprecationLevel.HIDDEN)
fun Api.startWithDocs(
    port: Int = 8080,
    host: String = "127.0.0.1",
    systemName: String = "pelican",
    docs: Docs = docs(),
): PelicanServer = startWithDocs(port, host, systemName, docs, Handlers.default)

/** The same, on a borrowed system. */
@Deprecated("Binary compatibility only: call startWithDocs with handlers.", level = DeprecationLevel.HIDDEN)
fun Api.startWithDocs(
    system: ActorSystem<Void>,
    port: Int = 8080,
    host: String = "127.0.0.1",
    docs: Docs = docs(),
): PelicanServer = startWithDocs(system, port, host, docs, Handlers.default)

/**
 * Matched against the request path directly rather than through a path matcher,
 * because these paths are configuration — `/api-docs/oauth2-redirect.html` is as
 * valid a setting as `/docs`, and a segment matcher would only handle the
 * one-segment case.
 */
private fun staticRoute(
    rawPath: String,
    contentType: ContentType.NonBinary,
    body: String,
    cors: CorsPolicy?,
): Route {
    val wanted = rawPath.trim('/')
    return Directives.get {
        Directives.extractRequest { req ->
            if (req.uri.pathString.trim('/') != wanted) Directives.reject()
            else {
                val origin = req.getHeader(CorsHeaders.ORIGIN).orElse(null)?.value()
                Directives.complete(
                    HttpResponse.create()
                        .withStatus(StatusCodes.OK)
                        .withEntity(HttpEntities.create(contentType, body))
                        .addHeaders(
                            cors?.actualResponseHeaders(origin)
                                .orEmpty()
                                .map { (name, value) -> RawHeader.create(name, value) },
                        ),
                )
            }
        }
    }
}
