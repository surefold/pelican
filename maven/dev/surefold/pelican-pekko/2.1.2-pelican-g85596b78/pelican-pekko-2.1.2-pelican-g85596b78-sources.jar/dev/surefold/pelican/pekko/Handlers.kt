package dev.surefold.pelican.pekko

import dev.surefold.pelican.ByteStream
import dev.surefold.pelican.ByteStreamHandle
import dev.surefold.pelican.Endpoint
import dev.surefold.pelican.Method
import dev.surefold.pelican.Outcome
import dev.surefold.pelican.Params
import dev.surefold.pelican.ServerEndpoint
import dev.surefold.pelican.StreamIn
import dev.surefold.pelican.StreamOf
import org.apache.pekko.NotUsed
import org.apache.pekko.actor.ClassicActorSystemProvider
import org.apache.pekko.http.javadsl.model.HttpMethod
import org.apache.pekko.http.javadsl.model.HttpMethods
import org.apache.pekko.http.javadsl.model.HttpRequest
import org.apache.pekko.stream.javadsl.Sink
import org.apache.pekko.stream.javadsl.Source
import org.apache.pekko.util.ByteString
import java.util.concurrent.CompletableFuture
import java.util.concurrent.CompletionStage
/**
 * The typed bridge between a backend-agnostic [Endpoint] and Pekko. Core cannot
 * name `Source`, so streaming endpoints carry the phantom marker [StreamOf];
 * this is where it is cashed in, with the element type still checked.
 */

// ------------------------------------------------------------- value outputs
//
// Every binder takes `Params.(I) -> ...` — a typed tuple with endpoint(a, b),
// Params in the lens style. The receiver lets a typed handler still reach
// `setHeader`, an attribute, or the backend's request. A lambda that ignores
// it is unchanged.

/** Binds an endpoint whose output is a single value. */
infix fun <I, T : Any> Endpoint<I, T>.handledBy(f: Params.(I) -> CompletionStage<T>): ServerEndpoint =
    ServerEndpoint(this) { p -> p.f(inputs.extract(p)).thenApply { it as Any? } }

/** Binds an endpoint whose output is a single value, computed synchronously: see [Handlers] for where. */
infix fun <I, T : Any> Endpoint<I, T>.handledNow(f: Params.(I) -> T): ServerEndpoint =
    ServerEndpoint(this, Synchronous { p -> CompletableFuture.completedFuture(p.f(inputs.extract(p)) as Any?) })

/** Binds an endpoint that returns no body. */
infix fun <I> Endpoint<I, Unit>.handledWith(f: Params.(I) -> Unit): ServerEndpoint =
    ServerEndpoint(this, Synchronous { p -> CompletableFuture.completedFuture(p.f(inputs.extract(p)) as Any?) })

// ------------------------------------------------------------- declared failures
//
// `orFail` makes an `Endpoint<I, Outcome<E, T>>`, and these are the only
// binders that fit it: the handler returns an `Outcome`, so an undeclared
// error is a compile error.
//
// Named apart rather than overloaded, because a lambda's return type is
// inferred after overload resolution.

/** Binds an endpoint that either succeeds with [T] or returns a declared failure. */
infix fun <I, E : Any, T : Any> Endpoint<I, Outcome<E, T>>.handledOrFail(
    f: Params.(I) -> Outcome<E, T>,
): ServerEndpoint = ServerEndpoint(
    this,
    Synchronous { p -> CompletableFuture.completedFuture(p.f(inputs.extract(p)) as Any?) },
)

/** As [handledOrFail], for a handler that answers asynchronously. */
infix fun <I, E : Any, T : Any> Endpoint<I, Outcome<E, T>>.handledByOrFail(
    f: Params.(I) -> CompletionStage<Outcome<E, T>>,
): ServerEndpoint = ServerEndpoint(this) { p -> p.f(inputs.extract(p)).thenApply { it as Any? } }

// ------------------------------------------------------------- several successes
//
// The same binder under the name that reads right when the alternatives are
// not failures — `Outcome<Nothing, T>` is the shape above with an empty
// failure side. Two names because `handledOrFail` on an endpoint declaring no
// failure reads as a mistake.

/** Binds an endpoint that answers with one of several declared responses. */
infix fun <I, E : Any, T : Any> Endpoint<I, Outcome<E, T>>.handledOneOf(
    f: Params.(I) -> Outcome<E, T>,
): ServerEndpoint = handledOrFail(f)

/** As [handledOneOf], for a handler that answers asynchronously. */
infix fun <I, E : Any, T : Any> Endpoint<I, Outcome<E, T>>.handledByOneOf(
    f: Params.(I) -> CompletionStage<Outcome<E, T>>,
): ServerEndpoint = handledByOrFail(f)

/** Binds a streaming endpoint that may fail before the first element. */
infix fun <I, E : Any, T> Endpoint<I, Outcome<E, StreamOf<T>>>.streamedOrFail(
    f: Params.(I) -> Outcome<E, Source<T, NotUsed>>,
): ServerEndpoint = ServerEndpoint(this) { p ->
    CompletableFuture.completedFuture(p.f(inputs.extract(p)) as Any?)
}

/** As [streamedOrFail], for a handler that decides asynchronously. */
infix fun <I, E : Any, T> Endpoint<I, Outcome<E, StreamOf<T>>>.streamedByOrFail(
    f: Params.(I) -> CompletionStage<Outcome<E, Source<T, NotUsed>>>,
): ServerEndpoint = ServerEndpoint(this) { p -> p.f(inputs.extract(p)).thenApply { it as Any? } }

// ------------------------------------------------------------- streams

/**
 * Binds a streaming endpoint. Building a `Source` is cheap and synchronous —
 * the work happens as it is consumed — so this is the usual case.
 */
infix fun <I, T> Endpoint<I, StreamOf<T>>.streamedNow(f: Params.(I) -> Source<T, NotUsed>): ServerEndpoint =
    ServerEndpoint(this) { p -> CompletableFuture.completedFuture(p.f(inputs.extract(p)) as Any?) }

/** Binds a streaming endpoint where deciding *what* to stream is itself async. */
infix fun <I, T> Endpoint<I, StreamOf<T>>.streamedBy(
    f: Params.(I) -> CompletionStage<Source<T, NotUsed>>,
): ServerEndpoint = ServerEndpoint(this) { p -> p.f(inputs.extract(p)).thenApply { it as Any? } }

/** Binds an endpoint that streams opaque bytes. */
infix fun <I> Endpoint<I, ByteStream>.bytesNow(f: Params.(I) -> Source<ByteString, NotUsed>): ServerEndpoint =
    ServerEndpoint(this) { p -> CompletableFuture.completedFuture(p.f(inputs.extract(p)) as Any?) }

/** Binds an endpoint streaming opaque bytes that may fail before the first one. */
infix fun <I, E : Any> Endpoint<I, Outcome<E, ByteStream>>.bytesOrFail(
    f: Params.(I) -> Outcome<E, Source<ByteString, NotUsed>>,
): ServerEndpoint = ServerEndpoint(this) { p ->
    CompletableFuture.completedFuture(p.f(inputs.extract(p)) as Any?)
}

// ------------------------------------------------------------- accessors

internal class PekkoByteStream(val source: Source<ByteString, Any>) : ByteStreamHandle

/** The request body as a Pekko source. Nothing has been read from it yet. */
fun ByteStreamHandle.toSource(): Source<ByteString, Any> =
    (this as PekkoByteStream).source

internal class PekkoFrames<T>(
    val source: Source<T, NotUsed>,
    /** The system the request arrived on, which is the one [runWith] runs the upload on. */
    val system: ClassicActorSystemProvider,
) : StreamIn<T>

/**
 * The frames of an `ndjsonIn` body as a Pekko source, unread and unbuffered:
 * a frame is decoded when the stage downstream of it pulls, so the upload is
 * consumed at the speed the handler consumes it.
 */
@Suppress("UNCHECKED_CAST")
fun <T> StreamIn<T>.toSource(): Source<T, NotUsed> = (this as PekkoFrames<T>).source

/**
 * Runs the upload into [sink] on the system this request arrived on.
 *
 * Here because a handler that answers with a *value* has to consume the upload
 * itself, and consuming a `Source` needs a materializer that nothing else in a
 * handler's reach carries. Answering with a stream needs none: the response is
 * the upload's own graph, and the interpreter materialises it.
 */
@Suppress("UNCHECKED_CAST")
fun <T, M> StreamIn<T>.runWith(sink: Sink<T, M>): M {
    val frames = this as PekkoFrames<T>
    return frames.source.runWith(sink, frames.system)
}

/** Escape hatch: the raw Pekko request behind this call. */
val Params.request: HttpRequest
    get() = underlying as HttpRequest

internal fun Method.toPekko(): HttpMethod = when (this) {
    Method.GET -> HttpMethods.GET
    Method.POST -> HttpMethods.POST
    Method.PUT -> HttpMethods.PUT
    Method.PATCH -> HttpMethods.PATCH
    Method.DELETE -> HttpMethods.DELETE
    Method.HEAD -> HttpMethods.HEAD
    Method.OPTIONS -> HttpMethods.OPTIONS
    Method.QUERY -> PEKKO_QUERY
}

/**
 * Pekko HTTP 2 has `QUERY` and its parser gives that one; 1.x has none, so a custom one. Equality is by every field,
 * so the server's parser and the routes must share whichever this is.
 */
val PEKKO_QUERY: HttpMethod = HttpMethods.lookup("QUERY").orElseGet {
    HttpMethods.custom("QUERY", true, true, HttpMethods.POST.requestEntityAcceptance())
}
