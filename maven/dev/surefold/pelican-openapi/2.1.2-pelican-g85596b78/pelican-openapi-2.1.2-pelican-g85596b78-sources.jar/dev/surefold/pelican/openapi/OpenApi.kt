// ktlint's `wrapping` rule puts every argument on its own line once a call
// spans more than one, which strands each key above its value and turns this
// file into a staircase. It is a required dependency of `indent`, so it cannot
// be switched off in .editorconfig.
@file:Suppress("ktlint:standard:wrapping")

package dev.surefold.pelican.openapi

import dev.surefold.pelican.ApiKeyScheme
import dev.surefold.pelican.ApiSpec
import dev.surefold.pelican.ByteStreamOutput
import dev.surefold.pelican.DeclaredResponses
import dev.surefold.pelican.EmptyOutput
import dev.surefold.pelican.Endpoint
import dev.surefold.pelican.ErrorSpec
import dev.surefold.pelican.FilePart
import dev.surefold.pelican.FormBody
import dev.surefold.pelican.HttpScheme
import dev.surefold.pelican.JsonArr
import dev.surefold.pelican.JsonArrayOutput
import dev.surefold.pelican.JsonBody
import dev.surefold.pelican.JsonBool
import dev.surefold.pelican.JsonNum
import dev.surefold.pelican.JsonObj
import dev.surefold.pelican.JsonObjBuilder
import dev.surefold.pelican.JsonOutput
import dev.surefold.pelican.JsonStr
import dev.surefold.pelican.JsonValue
import dev.surefold.pelican.ListStyle
import dev.surefold.pelican.MediaOutput
import dev.surefold.pelican.Method
import dev.surefold.pelican.MultipartBody
import dev.surefold.pelican.NdjsonBody
import dev.surefold.pelican.NdjsonOutput
import dev.surefold.pelican.NegotiatedBody
import dev.surefold.pelican.NegotiatedOutput
import dev.surefold.pelican.OAuth2Scheme
import dev.surefold.pelican.OAuthFlow
import dev.surefold.pelican.OpenIdConnectScheme
import dev.surefold.pelican.Output
import dev.surefold.pelican.PlainCodec
import dev.surefold.pelican.RawBody
import dev.surefold.pelican.RefusalRenderer
import dev.surefold.pelican.ResponseHeader
import dev.surefold.pelican.SchemaComponents
import dev.surefold.pelican.SchemaRegistry
import dev.surefold.pelican.SchemaSource
import dev.surefold.pelican.SecurityRequirement
import dev.surefold.pelican.SecurityScheme
import dev.surefold.pelican.SseOutput
import dev.surefold.pelican.StringCodec
import dev.surefold.pelican.TextOutput
import dev.surefold.pelican.TextPart
import dev.surefold.pelican.Webhook
import dev.surefold.pelican.default
import dev.surefold.pelican.defaultExplodeFor
import dev.surefold.pelican.defaultStyleAt
import dev.surefold.pelican.jsonArr
import dev.surefold.pelican.jsonObj
import dev.surefold.pelican.jsonStrings
import dev.surefold.pelican.listSchema
import dev.surefold.pelican.mediaType
import dev.surefold.pelican.openApiSchema
import dev.surefold.pelican.operationName
import dev.surefold.pelican.payloadType
import dev.surefold.pelican.renderPretty
import dev.surefold.pelican.securitySchemesOf
/**
 * Interprets endpoint descriptions as an OpenAPI document, written against
 * [version].
 *
 * The two revisions describe the same endpoints and differ in three places,
 * all of them cases where 3.1 has no vocabulary for something the server
 * actually does:
 *
 * - **The `openapi` field**, `3.1.0` or `3.2.0`.
 * - **Cookie parameters** carry `style: "cookie"` under 3.2. Pelican joins
 *   cookie pairs with `"; "` and passes values through unescaped, which is
 *   what that style means and is not what the `form` both revisions assume at
 *   this location means. See [serialisation].
 * - **NDJSON and SSE bodies**, sent or received, put their schema under
 *   `itemSchema` under 3.2 — the field 3.2 added for exactly this, describing
 *   one frame rather than the whole stream. See [successBody] and
 *   [requestBody].
 *
 * 3.0 is not on the list and will not be. Nullability is spelled inside a
 * schema rather than around it, so writing it would need either an OpenAPI
 * argument on core's [SchemaSource] — a type that exists so core need not know
 * what OpenAPI is — or a second emitter pattern-matching the first one's
 * output. Neither could be faithful: 3.0's `nullable` cannot say "this
 * reference may be null".
 */
fun ApiSpec.openApi(version: OpenApiVersion = OpenApiVersion.V3_1_0): JsonObj {
    val components = SchemaRegistry()

    // path template -> method -> operation
    val paths = LinkedHashMap<String, MutableMap<String, JsonValue>>()

    // Served but not published, so it reaches the document in no form at all.
    val documented = endpoints.filterNot { it.hidden }

    for (ep in documented) {
        val byMethod = paths.getOrPut(ep.pathSpec.template) { LinkedHashMap() }
        byMethod[operationKey(ep.method, version)] = operation(ep, version, schemas, components, refusals)
    }

    // A webhook says hidden the same way an endpoint does.
    val sent = webhooks.filterNot { it.operation.hidden }

    // Collected from the requirements referencing them, so a scheme cannot be
    // declared unused or used undeclared. A webhook's counts: it is the
    // credential this service presents to a subscriber.
    val schemes = securitySchemesOf(
        security + documented.flatMap { it.security.orEmpty() } +
            sent.flatMap { it.operation.security.orEmpty() },
    )

    val pathItems = JsonObj(paths.mapValues { (_, ops) -> JsonObj(ops.toMap()) })
    val webhookItems = webhookItems(sent, version, schemas, components, refusals)
    declareTags(
        documented.flatMap { it.errors } + sent.flatMap { it.operation.errors },
        schemas,
        components,
        listOf(pathItems, webhookItems, components.all()),
    )

    return jsonObj {
        "openapi" to version.field
        // `jsonSchemaDialect` is omitted: 2020-12 is what both revisions
        // already mean, and writing it down is a second place for it to be
        // wrong. `$self`, which 3.2 adds beside it, is omitted for a different
        // reason — it names the document's own retrieval URI, and nothing in a
        // set of endpoint descriptions says where the document gets published.
        put("info", info())
        if (servers.isNotEmpty()) put("servers", serverList(servers))
        put("paths", pathItems)
        // The order the specification lists the fields in; a document is read
        // by people too.
        if (sent.isNotEmpty()) put("webhooks", webhookItems)
        if (security.isNotEmpty()) put("security", requirements(security))
        put("components", jsonObj {
            put("schemas", components.all())
            if (schemes.isNotEmpty()) {
                put("securitySchemes", jsonObj { schemes.forEach { put(it.name, scheme(it)) } })
            }
        })
    }
}

fun ApiSpec.openApiJson(version: OpenApiVersion = OpenApiVersion.V3_1_0): String =
    openApi(version).renderPretty()

/**
 * What the document says about the API itself.
 *
 * A function of its own, and not four lines inlined above, because two
 * different things here are called a version: `info.version` is the API's,
 * which the service names and bumps, and the argument to [openApi] is the
 * specification's. Written in one scope the second would quietly shadow the
 * first, and the document would lose a required field without anything
 * complaining.
 */
private fun ApiSpec.info(): JsonObj = jsonObj {
    "title" to title
    "version" to version
    putIfNotNull("description", description)
}

/** `https://{tenant}.<parent>`, the tenant a variable a caller fills in. */
private fun tenantServer(parent: String): JsonObj = jsonObj {
    "url" to "https://{tenant}.$parent"
    put(
        "variables",
        jsonObj {
            put(
                "tenant",
                jsonObj {
                    "default" to "tenant"
                    "description" to "The tenant this request is for, as the first label of the host."
                },
            )
        },
    )
}

/**
 * A `servers` list, the same Server Object at document level and on an
 * operation. One function, so the two cannot disagree.
 */
private fun serverList(urls: List<String>): JsonArr =
    jsonArr(urls.map { url -> jsonObj { "url" to url } })

/**
 * `webhooks`: the calls the service sends, keyed by name rather than by path.
 * The value is a Path Item Object written by the same [operation] function,
 * since a webhook is one of these read in the other direction.
 */
private fun webhookItems(
    webhooks: List<Webhook>,
    version: OpenApiVersion,
    schemas: SchemaSource,
    components: SchemaComponents,
    refusals: RefusalRenderer,
): JsonObj {
    val items = LinkedHashMap<String, MutableMap<String, JsonValue>>()
    webhooks.forEach { hook ->
        items.getOrPut(hook.name) { LinkedHashMap() }[operationKey(hook.operation.method, version)] =
            operation(hook.operation, version, schemas, components, refusals)
    }
    return JsonObj(items.mapValues { (_, ops) -> JsonObj(ops.toMap()) })
}

/** 3.1 has no `query` field, so a `QUERY` is written under the `x-query` extension there and under `query` in 3.2. */
private fun operationKey(method: Method, version: OpenApiVersion): String = when {
    method == Method.QUERY && version == OpenApiVersion.V3_1_0 -> "x-query"
    else -> method.name.lowercase()
}

/** Every declared input that travels outside the body, in the order a reader expects them. */
private fun parameters(ep: Endpoint<*, *>, version: OpenApiVersion): List<JsonValue> = buildList {
    ep.pathSpec.captures.forEach { p ->
        add(parameter(p.name, "path", true, p.codec, p.description, version))
    }
    ep.queries.forEach { q ->
        add(parameter(q.name, "query", q.required, q.codec, q.description, version, q.listStyle, q.default))
    }
    ep.headerParams.forEach { h ->
        add(parameter(h.name, "header", h.required, h.codec, h.description, version, h.listStyle, h.default))
    }
    // Read by the signature check rather than declared as inputs, so a missing one is a signature refusal.
    ep.signedBy?.let { scheme ->
        scheme.headers.forEach { add(parameter(it, "header", true, StringCodec, scheme.description, version)) }
    }
    ep.cookieParams.forEach { c ->
        add(parameter(c.name, "cookie", c.required, c.codec, c.description, version, c.listStyle, c.default))
    }
}

/** The request body, or null where the endpoint declares none. */
private fun requestBody(
    ep: Endpoint<*, *>,
    version: OpenApiVersion,
    schemas: SchemaSource,
    components: SchemaComponents,
): JsonObj? =
    when (val body = ep.bodyInput) {
        is JsonBody<*> -> jsonObj {
            "required" to true
            putIfNotNull("description", body.description)
            put("content", jsonObj {
                put("application/json", jsonObj {
                    put("schema", schemas.schema(body.type, components))
                })
            })
        }

        // The same schema a JSON body would publish, because the form is
        // decoded against it — anything else would describe an impossible
        // decode.
        is FormBody<*> -> jsonObj {
            "required" to true
            putIfNotNull("description", body.description)
            put("content", jsonObj {
                put("application/x-www-form-urlencoded", jsonObj {
                    put("schema", schemas.schema(body.type, components))
                })
            })
        }

        is MultipartBody -> jsonObj {
            "required" to true
            putIfNotNull("description", body.description)
            put("content", jsonObj {
                put("multipart/form-data", jsonObj {
                    put("schema", multipartSchema(body))
                    multipartEncoding(body)?.let { put("encoding", it) }
                })
            })
        }

        is RawBody -> jsonObj {
            "required" to true
            putIfNotNull("description", body.description)
            put("content", jsonObj {
                put("application/octet-stream", jsonObj {
                    put("schema", binarySchema("application/octet-stream"))
                })
            })
        }

        // A sequential media type in the other direction, described the way a
        // sequential *response* is: `itemSchema` under 3.2, which is the field
        // that means one frame, and `schema` under 3.1, which has no other. The
        // rule is [successBody]'s and applies here for the same reason — the
        // frame is the thing a description knows about.
        is NdjsonBody<*> -> jsonObj {
            "required" to true
            putIfNotNull("description", body.description)
            val field = if (version == OpenApiVersion.V3_2_0) "itemSchema" else "schema"
            put("content", jsonObj {
                put("application/x-ndjson", jsonObj {
                    put(field, schemas.schema(body.type, components))
                })
            })
        }

        // One entry per encoding, all the same schema — one value arriving
        // several ways. Published once and shared, since entries that could
        // drift apart would describe two decodes rather than one.
        is NegotiatedBody<*> -> jsonObj {
            "required" to true
            putIfNotNull("description", body.description)
            val schema = schemas.schema(checkNotNull(body.payloadType), components)
            put("content", jsonObj {
                body.alternatives.forEach { alternative ->
                    put(alternative.mediaType, jsonObj { put("schema", schema) })
                }
            })
        }

        null -> null
    }

/**
 * One entry per successful response the output describes, one per declared
 * failure — each with its own schema and media type — and, where the endpoint
 * declares no `default` of its own, one for the refusals nothing declares.
 *
 * The refusal entry goes under `default` because that is what `default` means:
 * the answer for the statuses not enumerated above. A refusal is exactly that —
 * a 400 nothing could decode, a 406, a 413, a 500 — and the envelope it arrives
 * in is [Api.refusals] rather than anything on the endpoint, so it is written
 * once here from the same value the interpreters write the bytes from. An
 * endpoint that declares its own `default` keeps it: a description beats a
 * derivation.
 */
private fun responses(
    ep: Endpoint<*, *>,
    version: OpenApiVersion,
    schemas: SchemaSource,
    components: SchemaComponents,
    refusals: RefusalRenderer,
): JsonObj = jsonObj {
    successesOf(ep.output).forEach { out ->
        put(out.status.toString(), jsonObj {
            "description" to successDescription(out)
            responseHeaders(ep.responseHeaders + out.headers)?.let { put("headers", it) }
            successBody(out, version, schemas, components)?.let { put("content", it) }
        })
    }
    // Grouped, because two tagged failures share one status and so one entry: the status has one
    // slot in this map, and spec 0063's whole point is that the slot can hold both. Order is
    // declaration order, which `groupBy` keeps.
    ep.errors.groupBy { it.status }.forEach { (status, errs) ->
        // A null status is `default`: a key like any other, except that
        // nothing produces it and it stands for the statuses not enumerated.
        put(status?.toString() ?: "default", jsonObj {
            "description" to failureDescription(errs)
            // The endpoint's own headers ride on a failure too — `setHeader`
            // puts them on whatever response came back — but they are not
            // promised there: a filter that refuses never reaches the handler
            // that would have set one.
            responseHeaders(errs.flatMap { it.headers }, alsoSometimes = ep.responseHeaders)
                ?.let { put("headers", it) }
            failureBody(errs, schemas, components, refusedBy(ep, refusals))?.let { put("content", it) }
        })
    }
    if (ep.errors.none { it.status == null }) put("default", refusalResponse(refusals, components))
}

/**
 * What a request this endpoint refuses comes back as.
 *
 * A `$ref` to one component and not a schema repeated per operation: every
 * operation refuses in the same envelope, and a document that spells it out a
 * dozen times is a document `pelican-import` reads back as a dozen types. The
 * component keeps whatever definition it already has — under the default
 * envelope that is `ApiError`, which a service describing `errorJson<ApiError>`
 * has already published from the type itself.
 */
private fun refusalResponse(refusals: RefusalRenderer, components: SchemaComponents): JsonObj = jsonObj {
    "description" to "A refusal: this request was not answered by the operation above."
    put("content", jsonObj {
        put(refusals.mediaType, jsonObj { put("schema", refusalSchema(refusals, components)) })
    })
}

private fun refusalSchema(refusals: RefusalRenderer, components: SchemaComponents): JsonObj {
    if (!components.isRegistered(refusals.componentName)) {
        components.register(refusals.componentName, refusals.schema)
    }
    return components.ref(refusals.componentName)
}

/**
 * The failures this endpoint declares that Pelican answers rather than the handler: its caller's 401 and 403s,
 * and an idempotency key's 409 and 422, written in the refusal envelope because that is what the wire carries them in.
 */
private fun refusedBy(ep: Endpoint<*, *>, refusals: RefusalRenderer): (ErrorSpec) -> RefusalRenderer? {
    val answered = listOfNotNull(
        ep.idempotency?.inFlight,
        ep.idempotency?.reused,
        ep.caller?.refused,
        ep.requires?.refused,
        ep.caller?.crossSiteRefused,
        ep.tenant?.missing,
        ep.tenant?.unknown,
        ep.tenant?.foreign,
        ep.rateLimit?.refused,
        ep.signedBy?.refused,
    )
    return { err -> if (answered.any { it === err }) refusals else null }
}

/**
 * What a status's failures say. Several tagged ones are listed with the tag a reader branches on,
 * since joined into one line they read as one garbled sentence; Markdown is what OpenAPI renders a
 * description as.
 */
private fun failureDescription(errs: List<ErrorSpec>): String =
    if (errs.size > 1 && errs.all { it.tag != null }) {
        "One of:\n\n" + errs.joinToString("\n") { "- `${it.tag}`: ${it.description}" }
    } else {
        errs.joinToString("; ") { it.description }
    }

/**
 * The `content` of a failure response: one schema where the status has one failure, and a `oneOf`
 * discriminated by the tag where it has several.
 *
 * The discriminator is what a client outside Pelican branches on — the whole reason for writing the
 * tag into the body rather than keeping a sealed payload — so it is emitted whenever every schema
 * under the status is a `$ref` it can name. An inline schema cannot be mapped to, so a `oneOf`
 * without the mapping is emitted instead: still a document saying there are two shapes, which is
 * better than one naming a target that is not there.
 */
private fun failureBody(
    errs: List<ErrorSpec>,
    schemas: SchemaSource,
    components: SchemaComponents,
    refusedBy: (ErrorSpec) -> RefusalRenderer?,
): JsonObj? {
    val described = errs.mapNotNull { err ->
        val refusals = refusedBy(err)
        when {
            refusals != null -> Triple(refusals.mediaType, err, refusalSchema(refusals, components))
            else -> err.type?.let { Triple(err.mediaType, err, schemas.schema(it, components)) }
        }
    }
    if (described.isEmpty()) return null

    // Under the media type each is written as (spec 0070): JSON unless declared with errorMedia.
    return JsonObj(
        described.groupBy({ it.first }, { it.second to it.third }).mapValues { (_, under) ->
            jsonObj { put("schema", schemaOf(under)) }
        },
    )
}

/** One schema where one failure is written as a media type, and a `oneOf` discriminated by tag where several are. */
private fun schemaOf(described: List<Pair<ErrorSpec, JsonObj>>): JsonObj = when {
    described.size == 1 -> described.single().second

    else -> jsonObj {
        put("oneOf", jsonArr(described.map { (_, schema) -> schema }))
        discriminator(described)?.let { put("discriminator", it) }
    }
}

/** The tag field and which schema each tag means, or null where a schema cannot be referred to. */
private fun discriminator(described: List<Pair<ErrorSpec, JsonObj>>): JsonObj? {
    val mapped = described.mapNotNull { (err, schema) ->
        val tag = err.tag ?: return@mapNotNull null
        (schema["\$ref"] as? JsonStr)?.let { tag to it }
    }
    if (mapped.size != described.size) return null
    return jsonObj {
        // Any of them: the endpoint refuses a status whose failures disagree on the field, so one
        // status has one discriminator here by construction rather than by picking a winner.
        "propertyName" to described.first().first.discriminator
        put("mapping", JsonObj(mapped.toMap()))
    }
}

/** The successful responses an output describes: several where it names them, else itself. */
private fun successesOf(out: Output<*>): List<Output<*>> =
    if (out is DeclaredResponses<*, *>) out.successes else listOf(out)

/**
 * The `content` of a successful response: which media type it is, and which
 * field the schema goes under.
 *
 * NDJSON and SSE are what 3.2 calls *sequential media types* — a repeating
 * structure with no header, footer or envelope around it, and both are named
 * in its list of them. It is explicit about the consequence: `schema` "MUST be
 * applied to the complete content", the whole stream read as though the frames
 * were an array, while `itemSchema` "MUST be applied to each item in the
 * stream independently". One frame is the thing an endpoint description knows
 * about, so under 3.2 the document puts it in the field that means it. Under
 * 3.1 there is only `schema`, and the frame's schema goes there — the reading
 * everything generating streamed responses used before `itemSchema` existed,
 * and the one 3.2 now says is the wrong field.
 *
 * A streamed JSON array is not sequential under either revision: it is one
 * document with brackets round it that happens to arrive in pieces. So
 * [JsonArrayOutput] keeps `schema: {"type": "array"}` throughout.
 */
private fun successBody(
    out: Output<*>,
    version: OpenApiVersion,
    schemas: SchemaSource,
    components: SchemaComponents,
): JsonObj? {
    if (out is DeclaredResponses<*, *>) return successBody(out.success, version, schemas, components)

    // One entry per rendering, all the same schema — one value written several
    // ways, as a negotiated *request* body is one value read several ways.
    // Published once and shared, since entries that could drift apart would
    // describe two responses rather than one.
    if (out is NegotiatedOutput<*>) {
        val schema = schemaOf(out.alternatives.first(), version, schemas, components) ?: return null
        return jsonObj {
            out.alternatives.forEach { alternative ->
                put(checkNotNull(alternative.mediaType), jsonObj { put("schema", schema) })
            }
        }
    }

    val media = out.mediaType ?: return null
    val schema = schemaOf(out, version, schemas, components) ?: return null
    val field = if (version == OpenApiVersion.V3_2_0 && out.isSequential()) "itemSchema" else "schema"
    return jsonObj { put(media, jsonObj { put(field, schema) }) }
}

/** The outputs whose media type repeats one structure with nothing around it. */
private fun Output<*>.isSequential(): Boolean = this is NdjsonOutput<*> || this is SseOutput<*>

/**
 * What an id is *for*, said in the document, because a caller cannot infer from
 * a string field that sending it back is how the stream is picked up again.
 */
private const val RESUME_CONTRACT: String =
    "The event's id. Send the last one received as `Last-Event-ID` to resume the stream from " +
        "that point; a connection that sends none starts from now."

/**
 * One event of a `text/event-stream`, as 3.2 asks for it to be described.
 *
 * An item of an event stream is not the payload. 3.2 requires implementations
 * to "work with event data after it has been parsed according to the
 * `text/event-stream` specification", and what that parse yields is an event
 * with `data`, `event` and `id` fields — so saying `itemSchema` is the payload
 * type would describe a stream nobody sends. Each field is here exactly when
 * [SseOutput.frame] writes it, on the same principle that stops a response
 * header being documented and not sent.
 *
 * `retry` is not among them. It is a directive about the stream rather than a
 * field of a dispatched event, and it goes out once ahead of the first one; the
 * response's description is where it is said.
 *
 * `data` is a string, because every SSE field is. What is inside the string is
 * said with `contentMediaType` and `contentSchema`, which is the pair 3.2
 * points at for this exact case: some users of `text/event-stream` put JSON in
 * the `data` field, and those are the keywords for describing it.
 */
private fun sseEventSchema(
    out: SseOutput<*>,
    schemas: SchemaSource,
    components: SchemaComponents,
): JsonObj = jsonObj {
    "type" to "object"
    // In the order the frame writes them, since a document is read by people too.
    put("properties", jsonObj {
        out.eventName?.let { name ->
            put("event", jsonObj {
                "type" to "string"
                "const" to name
            })
        }
        if (out.id != null) {
            put("id", jsonObj {
                "type" to "string"
                "description" to RESUME_CONTRACT
            })
        }
        put("data", jsonObj {
            "type" to "string"
            "contentMediaType" to "application/json"
            put("contentSchema", schemas.schema(out.type, components))
        })
    })
    // Every frame carries every field the output declared, so each of them is
    // required. A named stream always writes its name; an unnamed one never
    // does, and the same goes for an id.
    put(
        "required",
        jsonStrings(listOfNotNull(out.eventName?.let { "event" }, out.id?.let { "id" }, "data")),
    )
}

private fun operation(
    ep: Endpoint<*, *>,
    version: OpenApiVersion,
    schemas: SchemaSource,
    components: SchemaComponents,
    refusals: RefusalRenderer,
): JsonObj = jsonObj {
    putIfNotNull("summary", ep.summary)
    putIfNotNull("description", operationDescription(ep))
    "operationId" to ep.operationName
    if (ep.tags.isNotEmpty()) put("tags", jsonStrings(ep.tags))
    if (ep.deprecated) "deprecated" to true

    // Null inherits the document-wide requirement; an empty list is
    // deliberately public, which OpenAPI spells as `security: []`.
    ep.security?.let { reqs ->
        // An optional caller is OpenAPI's empty requirement beside the scheme: anyone, or someone signed in.
        val anyone = if (ep.caller?.required == false) listOf(jsonObj { }) else emptyList()
        put("security", jsonArr(anyone + requirements(reqs).items))
    }

    // Where this one operation is served from, in the same shape as the
    // document's own list and from the same function.
    // A tenant in the subdomain is a host the caller fills in, which is what a server variable is.
    val tenantHost = ep.tenant?.subdomainOf
    when {
        tenantHost != null -> put("servers", jsonArr(listOf(tenantServer(tenantHost))))
        ep.servers.isNotEmpty() -> put("servers", serverList(ep.servers))
    }

    val params = parameters(ep, version)
    if (params.isNotEmpty()) put("parameters", jsonArr(params))

    requestBody(ep, version, schemas, components)?.let { put("requestBody", it) }

    put("responses", responses(ep, version, schemas, components, refusals))
}

/**
 * Reads the payload schema out of an output description. The streaming outputs
 * document one *item* — an NDJSON line, an SSE event — except [JsonArrayOutput],
 * which is a whole array; [successBody] decides which field that item goes
 * under.
 */
private fun schemaOf(
    out: Output<*>,
    version: OpenApiVersion,
    schemas: SchemaSource,
    components: SchemaComponents,
): JsonObj? = when (out) {
    is JsonOutput<*> -> schemas.schema(out.type, components)

    is NdjsonOutput<*> -> schemas.schema(out.type, components)

    // An SSE item is the parsed event rather than the payload, which is a
    // thing only 3.2 gives the vocabulary to say; see [sseEventSchema].
    is SseOutput<*> -> when (version) {
        OpenApiVersion.V3_2_0 -> sseEventSchema(out, schemas, components)
        OpenApiVersion.V3_1_0 -> schemas.schema(out.type, components)
    }

    is JsonArrayOutput<*> -> jsonObj {
        "type" to "array"
        put("items", schemas.schema(out.type, components))
    }

    is ByteStreamOutput -> binarySchema(out.mediaType)

    is TextOutput -> jsonObj { "type" to "string" }

    // The media type is the encoding, and the schema is the value it encodes:
    // the same one the JSON rendering beside it publishes.
    is MediaOutput<*> -> schemas.schema(out.type, components)

    is EmptyOutput -> null

    // Failures are documented from ep.errors, so this is the success schema.
    is DeclaredResponses<*, *> -> schemaOf(out.success, version, schemas, components)

    // Every rendering carries one value; `successBody` puts that schema under
    // each of the media types.
    is NegotiatedOutput<*> -> schemaOf(out.alternatives.first(), version, schemas, components)
}

/**
 * The headers a response carries, as OpenAPI shapes them: a parameter object
 * without `name` and `in`. The same [ResponseHeader] values the handler sets,
 * so a header cannot be documented and not sent, or the reverse.
 */
private fun responseHeaders(
    headers: List<ResponseHeader<*>>,
    alsoSometimes: List<ResponseHeader<*>> = emptyList(),
): JsonObj? {
    if (headers.isEmpty() && alsoSometimes.isEmpty()) return null
    val sometimes = alsoSometimes.filterNot { extra -> headers.any { it === extra } }
    return jsonObj {
        (headers + sometimes).forEach { h ->
            put(h.name, jsonObj {
                "required" to (h.required && h !in sometimes)
                putIfNotNull("description", h.description ?: h.codec.description)
                putIfNotNull("example", h.codec.example)
                put("schema", h.codec.openApiSchema())
            })
        }
    }
}

/**
 * Opaque bytes, as 3.1's `contentMediaType` rather than 3.0's `format: binary`,
 * which JSON Schema never defined. No `contentEncoding`: these bytes go on the
 * wire as themselves.
 */
private fun binarySchema(mediaType: String) = jsonObj {
    "type" to "string"
    "contentMediaType" to mediaType
}

/**
 * A multipart envelope as OpenAPI models it: one property per part, a file
 * part's `contentMediaType` being what says it is a file.
 *
 * Text parts' schemas come from their own codecs, so a refinement is documented
 * as it would be on a query parameter and Swagger UI refuses to submit a value
 * the server would reject.
 */
private fun multipartSchema(body: MultipartBody): JsonObj = jsonObj {
    "type" to "object"
    put("properties", jsonObj {
        body.parts.forEach { part ->
            when (part) {
                is TextPart<*> -> put(part.name, describedSchema(part.codec.openApiSchema(),
                    part.description ?: part.codec.description,))

                is FilePart<*> -> put(
                    part.name,
                    describedSchema(binarySchema(part.contentType ?: "application/octet-stream"), part.description)
                        .let { schema ->
                            val bound = part.bufferedBytes
                            if (bound == null) schema else schema + jsonObj { "maxLength" to bound }
                        },
                )
            }
        }
    })
    val required = body.parts.filter { (it is TextPart<*> && it.required) || (it is FilePart<*> && it.required) }
    if (required.isNotEmpty()) put("required", jsonStrings(required.map { it.name }))
}

private fun describedSchema(schema: JsonObj, description: String?): JsonObj =
    if (description == null) schema else schema + jsonObj { "description" to description }

/**
 * What each file part is expected to carry, omitted when no part says: OpenAPI
 * already defaults a binary property to `application/octet-stream`.
 */
private fun multipartEncoding(body: MultipartBody): JsonObj? {
    val declared = body.fileParts.mapNotNull { part -> part.contentType?.let { part.name to it } }
    if (declared.isEmpty()) return null
    return jsonObj {
        declared.forEach { (name, contentType) ->
            put(name, jsonObj { "contentType" to contentType })
        }
    }
}

/** What the author wrote, then what the caller must have: OpenAPI has no field for a role, nor for "all of". */
private fun operationDescription(ep: Endpoint<*, *>): String? {
    val requires = ep.requires?.let { "Requires $it." }
    val limited = ep.rateLimit?.let { limited ->
        val whose = listOfNotNull(
            "caller".takeIf { ep.caller != null },
            "tenant".takeIf { ep.tenant != null },
            "key".takeIf { limited.keyed },
        )
        "Rate limited per ${whose.joinToString(" and ")} to ${limited.limit.bucket}, as `${limited.limit.name}`."
    }
    return listOfNotNull(ep.description, requires, limited).joinToString("\n\n").ifEmpty { null }
}

private fun successDescription(out: Output<*>): String = out.description ?: impliedDescription(out)

/** What the media type says when the response does not say for itself. */
private fun impliedDescription(out: Output<*>): String = when (out) {
    is NdjsonOutput<*> -> "A newline-delimited JSON stream. Chunked; consume incrementally."
    is JsonArrayOutput<*> -> "A JSON array, chunked; elements are flushed as they are produced."
    is SseOutput<*> -> "A server-sent event stream." + reconnectionNote(out)
    is ByteStreamOutput -> "A byte stream."
    is EmptyOutput -> "No content."
    is DeclaredResponses<*, *> -> successDescription(out.success)
    else -> "Success."
}

/**
 * The reconnection time in words, because it is a directive about the stream
 * rather than a field of any event the described item could carry it on.
 */
private fun reconnectionNote(out: SseOutput<*>): String =
    out.retry?.let { " Clients are asked to wait ${it.inWholeMilliseconds}ms before reconnecting." }.orEmpty()

/**
 * A parameter's own description wins; a self-documenting codec supplies one
 * everywhere it is used. Refinements ride along in the schema, so the document
 * states the constraint the server enforces.
 */
private fun parameter(
    name: String,
    location: String,
    required: Boolean,
    codec: PlainCodec<*>,
    description: String?,
    version: OpenApiVersion,
    listStyle: ListStyle? = null,
    default: Any? = null,
): JsonObj = jsonObj {
    "name" to name
    "in" to location
    "required" to required
    putIfNotNull("description", description ?: codec.description)
    // A list's example is an example of its element, and lives in `items`.
    if (listStyle == null) putIfNotNull("example", codec.example)
    serialisation(listStyle, location, version)
    // What the server puts in when the caller leaves it out. It reaches the
    // document through the same codec the wire does, so the two spell it alike
    // — `AGENTS.md` asks that of a refinement, and a default is the same claim
    // pointing the other way.
    val schema = if (listStyle == null) codec.openApiSchema() else listSchema(codec)
    put("schema", if (default == null) schema else schema + jsonObj { put("default", defaultOf(codec, default)) })
}

/**
 * A default as the JSON type its own schema describes: `50` under
 * `type: integer`, `"en"` under `type: string`. A number written as a string
 * would fail the schema it sits in.
 */
private fun defaultOf(codec: PlainCodec<*>, value: Any): JsonValue {
    @Suppress("UNCHECKED_CAST")
    val encoded = (codec as PlainCodec<Any>).encode(value)
    return when (codec.openApiType) {
        "integer" -> encoded.toLongOrNull()?.let { JsonNum(it) } ?: JsonStr(encoded)
        "number" -> encoded.toDoubleOrNull()?.takeIf { it.isFinite() }?.let { JsonNum(it) } ?: JsonStr(encoded)
        "boolean" -> encoded.toBooleanStrictOrNull()?.let { JsonBool(it) } ?: JsonStr(encoded)
        else -> JsonStr(encoded)
    }
}

/**
 * `style` and `explode`, written only where they differ from what OpenAPI
 * assumes at this location — so a reader who meets one can conclude something
 * unusual is being said.
 *
 * A cookie is the exception under 3.2, where the style is written whether or
 * not the parameter carries a list. `Cookies.render` joins pairs with `"; "`
 * and passes values through exactly as they were given, refusing the
 * characters RFC 6265 excludes rather than escaping them — which is what 3.2
 * defines `style: "cookie"` to mean, and is not what the `form` that both
 * revisions still assume at this location means. Appendix D says so directly:
 * `form`'s default `explode: true` "uses the wrong delimiter for cookies (`&`
 * instead of `;` followed by a single space)", and `form` percent-encodes
 * where `cookie` does not. 3.1 defines no `cookie` style, so under 3.1 the
 * document says the nearest thing available to it and a reader has to know
 * that cookies are not really `form`.
 */
private fun JsonObjBuilder.serialisation(style: ListStyle?, location: String, version: OpenApiVersion) {
    if (location == "cookie" && version == OpenApiVersion.V3_2_0) {
        "style" to "cookie"
        // Nothing follows it. `explode` defaults to true for `cookie` exactly
        // as it does for `form`, and `repeated()` is the only list a cookie
        // can carry, so the default is always the truth here.
        return
    }
    if (style == null) return
    val named = style.styleAt(location)
    if (named != defaultStyleAt(location)) "style" to named
    if (style.explode != defaultExplodeFor(named)) "explode" to style.explode
}

// ------------------------------------------------------------------ security

private fun requirements(reqs: List<SecurityRequirement>): JsonArr =
    jsonArr(reqs.map { req -> jsonObj { put(req.scheme.name, jsonStrings(req.scopes)) } })

private fun scheme(s: SecurityScheme): JsonObj = jsonObj {
    putIfNotNull("description", s.description)
    when (s) {
        is ApiKeyScheme -> {
            "type" to "apiKey"
            "in" to s.location
            "name" to s.paramName
        }

        is HttpScheme -> {
            "type" to "http"
            "scheme" to s.scheme
            putIfNotNull("bearerFormat", s.bearerFormat)
        }

        is OpenIdConnectScheme -> {
            "type" to "openIdConnect"
            "openIdConnectUrl" to s.openIdConnectUrl
        }

        is OAuth2Scheme -> {
            "type" to "oauth2"
            put("flows", jsonObj { s.flows.forEach { put(flowName(it), flow(it)) } })
        }
    }
}

private fun flowName(f: OAuthFlow): String = when (f) {
    is OAuthFlow.AuthorizationCode -> "authorizationCode"
    is OAuthFlow.ClientCredentials -> "clientCredentials"
    is OAuthFlow.Password -> "password"
    is OAuthFlow.Implicit -> "implicit"
}

private fun flow(f: OAuthFlow): JsonObj = jsonObj {
    when (f) {
        is OAuthFlow.AuthorizationCode -> {
            "authorizationUrl" to f.authorizationUrl
            "tokenUrl" to f.tokenUrl
            putIfNotNull("refreshUrl", f.refreshUrl)
        }

        is OAuthFlow.ClientCredentials -> {
            "tokenUrl" to f.tokenUrl
            putIfNotNull("refreshUrl", f.refreshUrl)
        }

        is OAuthFlow.Password -> {
            "tokenUrl" to f.tokenUrl
            putIfNotNull("refreshUrl", f.refreshUrl)
        }

        is OAuthFlow.Implicit -> {
            "authorizationUrl" to f.authorizationUrl
            putIfNotNull("refreshUrl", f.refreshUrl)
        }
    }
    // Always present, even when empty: OpenAPI requires the field, and
    // Swagger UI builds the scope checkboxes from it.
    put("scopes", jsonObj { f.scopes.forEach { (name, granted) -> put(name, JsonStr(granted)) } })
}
