package dev.surefold.pelican.importer

import dev.surefold.pelican.JsonObj
import dev.surefold.pelican.JsonValue
import dev.surefold.pelican.ListStyle

/**
 * What an imported document looks like once the OpenAPI-shaped noise is gone.
 */

internal class IrApi(
    val title: String,
    val version: String,
    val description: String?,
    val servers: List<String>,
    val security: List<IrRequirement>,
    val schemes: List<IrScheme>,
    val schemas: JsonObj,
    val endpoints: List<IrEndpoint>,
    /** The document's `webhooks`: calls the service sends, keyed by name rather than by path. */
    val webhooks: List<IrWebhook>,
)

/**
 * One entry of the document's `webhooks`.
 */
internal class IrWebhook(val name: String, val operation: IrEndpoint) {
    override fun toString() = "webhook $name (${operation.method})"
}

internal class IrEndpoint(
    val operationId: String,
    val method: String,
    val path: String,
    val summary: String?,
    val description: String?,
    val tags: List<String>,
    val deprecated: Boolean,
    val params: List<IrParam>,
    /** Where this operation is served, where the document says that is not where the API is. */
    val servers: List<String>,
    val body: IrBody?,
    /** Every documented 2xx, in status order. The first is what a bare `ok(...)` means. */
    val successes: List<IrSuccess>,
    val failures: List<IrFailure>,
    val responseHeaders: List<IrResponseHeader>,
    /** Null means "whatever the document requires"; empty means deliberately public. */
    val security: List<IrRequirement>?,
    /** Whether a key is required, where the operation declares one; null where it does not. */
    val idempotencyKey: Boolean? = null,
) {
    override fun toString() = "$operationId ($method $path)"
}

internal class IrParam(
    val name: String,
    val location: String,
    val required: Boolean,
    /**
     * The schema for one value. For a list that is the element's, since the
     * array around it is said by [listStyle] rather than by a schema.
     */
    val schema: JsonObj,
    val description: String?,
    val default: JsonValue?,
    /** What the document offers as a sample value, for the ones that are strings. */
    val example: String?,
    /** Null where the parameter carries one value; otherwise how several are spread. */
    val listStyle: ListStyle? = null,
)

internal sealed class IrBody {
    abstract val description: String?

    class Json(val schema: JsonObj, override val description: String?) : IrBody()
    class Form(val schema: JsonObj, override val description: String?) : IrBody()
    class Multipart(val parts: List<IrPart>, override val description: String?) : IrBody()
    class Raw(override val description: String?) : IrBody()

    /** [schema] is one frame's, which is what `ndjsonIn<T>` names. */
    class Ndjson(val schema: JsonObj, override val description: String?) : IrBody()

    /**
     * One payload, offered under several media types. [encodings] are in the
     * document's own order, since that is what decides which one a generated
     * client sends.
     */
    class Negotiated(
        val schema: JsonObj,
        val encodings: List<String>,
        override val description: String?,
    ) : IrBody()
}

internal sealed class IrPart {
    abstract val name: String
    abstract val required: Boolean
    abstract val description: String?

    class Text(
        override val name: String,
        val schema: JsonObj,
        override val required: Boolean,
        override val description: String?,
    ) : IrPart()

    class File(
        override val name: String,
        val contentType: String?,
        override val required: Boolean,
        override val description: String?,
        /** Null for the one part that is streamed; otherwise the bytes it is read with. */
        val bufferedBytes: Long? = null,
    ) : IrPart()
}

/**
 * One 2xx response, as the output that describes it.
 */
internal sealed class IrSuccess {
    abstract val status: Int
    abstract val headers: List<IrResponseHeader>

    class Json(
        override val status: Int,
        val schema: JsonObj,
        override val headers: List<IrResponseHeader> = emptyList(),
    ) : IrSuccess()

    class Ndjson(
        override val status: Int,
        val schema: JsonObj,
        override val headers: List<IrResponseHeader> = emptyList(),
    ) : IrSuccess()

    class Sse(
        override val status: Int,
        val schema: JsonObj,
        override val headers: List<IrResponseHeader> = emptyList(),
    ) : IrSuccess()

    class Text(
        override val status: Int,
        override val headers: List<IrResponseHeader> = emptyList(),
    ) : IrSuccess()

    class Bytes(
        override val status: Int,
        val mediaType: String,
        override val headers: List<IrResponseHeader> = emptyList(),
    ) : IrSuccess()

    class Empty(
        override val status: Int,
        override val headers: List<IrResponseHeader> = emptyList(),
    ) : IrSuccess()

    /**
     * One response documented under several media types: the same schema in
     * each, which is the only reading of a multi-entry content map an endpoint
     * description can hold — one value, written each of those ways.
     */
    class Negotiated(
        override val status: Int,
        val schema: JsonObj,
        /** In document order. The first is what a caller naming no preference gets. */
        val mediaTypes: List<String>,
        override val headers: List<IrResponseHeader> = emptyList(),
    ) : IrSuccess()
}

/** Whether producing this response means handing over a stream rather than a value. */
internal fun IrSuccess.streams(): Boolean =
    this is IrSuccess.Ndjson || this is IrSuccess.Sse || this is IrSuccess.Bytes

/**
 * The same response with the headers it carries. Read after the response
 * itself, because whether they belong here or to the endpoint depends on how
 * many successes there turned out to be.
 */
internal fun IrSuccess.with(headers: List<IrResponseHeader>): IrSuccess = when (this) {
    is IrSuccess.Json -> IrSuccess.Json(status, schema, headers)
    is IrSuccess.Ndjson -> IrSuccess.Ndjson(status, schema, headers)
    is IrSuccess.Sse -> IrSuccess.Sse(status, schema, headers)
    is IrSuccess.Text -> IrSuccess.Text(status, headers)
    is IrSuccess.Bytes -> IrSuccess.Bytes(status, mediaType, headers)
    is IrSuccess.Empty -> IrSuccess.Empty(status, headers)
    is IrSuccess.Negotiated -> IrSuccess.Negotiated(status, schema, mediaTypes, headers)
}

/** A documented non-2xx. One with a JSON body becomes a typed failure; one without is documented only. */
internal class IrFailure(
    /** Null is the document's `default` — "and anything else", which has no status of its own. */
    val status: Int?,
    val schema: JsonObj?,
    val description: String,
    val headers: List<IrResponseHeader>,
)

/**
 * Whether a handler could answer with this, which decides both the binder the
 * stub is written against and whether the failure is named on the output.
 */
internal val IrFailure.returnable: Boolean get() = status != null && schema != null

internal class IrResponseHeader(
    val name: String,
    val schema: JsonObj,
    val description: String?,
    val required: Boolean,
    val example: String?,
)

internal class IrRequirement(val scheme: String, val scopes: List<String>)

internal sealed class IrScheme {
    abstract val name: String
    abstract val description: String?

    class ApiKey(
        override val name: String,
        val location: String,
        val paramName: String,
        override val description: String?,
    ) : IrScheme()

    class Http(
        override val name: String,
        val scheme: String,
        val bearerFormat: String?,
        override val description: String?,
    ) : IrScheme()

    class OpenId(
        override val name: String,
        val url: String,
        override val description: String?,
    ) : IrScheme()

    class OAuth2(
        override val name: String,
        val flows: List<IrFlow>,
        override val description: String?,
    ) : IrScheme()
}

/**
 * Every schema this endpoint carries, wherever it sat. Two readers want the
 * same list — the one checking what can be described, and the one working out
 * which named schemas are reached — and a list assembled twice is a list that
 * ends up different.
 */
internal fun IrEndpoint.schemas(): List<JsonObj> = buildList {
    params.forEach { add(it.schema) }
    when (val declared = body) {
        is IrBody.Json -> add(declared.schema)
        is IrBody.Form -> add(declared.schema)
        is IrBody.Ndjson -> add(declared.schema)
        is IrBody.Negotiated -> add(declared.schema)
        is IrBody.Multipart -> declared.parts.filterIsInstance<IrPart.Text>().forEach { add(it.schema) }
        is IrBody.Raw, null -> Unit
    }
    successes.forEach { answered ->
        when (answered) {
            is IrSuccess.Json -> add(answered.schema)
            is IrSuccess.Ndjson -> add(answered.schema)
            is IrSuccess.Sse -> add(answered.schema)
            else -> Unit
        }
    }
    failures.forEach { failure -> failure.schema?.let { add(it) } }
    responseHeaders.forEach { add(it.schema) }
    successes.flatMap { it.headers }.forEach { add(it.schema) }
    failures.flatMap { it.headers }.forEach { add(it.schema) }
}

internal class IrFlow(
    val kind: String,
    val authorizationUrl: String?,
    val tokenUrl: String?,
    val refreshUrl: String?,
    val scopes: Map<String, String>,
)
